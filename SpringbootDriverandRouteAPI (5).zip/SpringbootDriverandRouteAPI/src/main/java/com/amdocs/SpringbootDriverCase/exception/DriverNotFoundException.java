package com.amdocs.SpringbootDriverCase.exception;

public class DriverNotFoundException extends Exception{
public DriverNotFoundException(String Message) {
		
		System.out.println(Message);
	}

}
