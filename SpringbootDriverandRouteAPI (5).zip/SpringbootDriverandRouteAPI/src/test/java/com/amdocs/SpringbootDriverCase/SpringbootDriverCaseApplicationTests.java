package com.amdocs.SpringbootDriverCase;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDriverCaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
